A Pen created at CodePen.io. You can find this one at https://codepen.io/mallendeo/pen/dvbQQx.

 Intro of [Marques Brownlee (aka MKBHD)](https://www.youtube.com/user/marquesbrownlee), one of my favorite youtubers.

Sometimes it flickers at the beggining, sometimes it plays flawlessly ¯\\\_(ツ)\_/¯ 

*only tested on Chrome*

