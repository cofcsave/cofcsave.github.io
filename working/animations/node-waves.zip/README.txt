A Pen created at CodePen.io. You can find this one at https://codepen.io/mattsince87/pen/MbqvrV.

 This is the first time i've really played with [three.js](https://threejs.org/). I've just been familiarising myself with the basics and will be using this in my new portfolio website i'm working on. Hope you like it!