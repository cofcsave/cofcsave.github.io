A Pen created at CodePen.io. You can find this one at https://codepen.io/supersarap/pen/EsAyn.

 So the active state on the navigation will change on click as well as on scroll. Having a little trouble with active state when going back up. 

Again, new to jquery so if you have any suggestions, please let me know!